package com.niit.shopingcart;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shopingcart.dao.UserDAO;
import com.niit.shopingcart.model.User;

public class UserTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();

		context.scan("com.niit.shopingcart");
		context.refresh();

		UserDAO userDAO = (UserDAO) context.getBean("userDAO");

		User user = (User) context.getBean("user");

		user.setId("SA234");
		user.setName("Sam");
		user.setPassword("sudharshan");
		user.setMobile("Apple");
		user.setMail("sudharshankumarreddy480@gmail.com");
		user.setAddress("Tirupathi");

		userDAO.saveOrUpdate(user);

		if (userDAO.get("SA234") == null) {
			System.out.println("user does not exist");
		} 
		else {
			System.out.println("user exist .. the details are ..");
			System.out.println();
		}

	}

}
