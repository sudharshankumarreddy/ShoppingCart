package com.niit.shopingcart;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shopingcart.dao.ProductDAO;
import com.niit.shopingcart.model.Product;

public class ProductTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();

context.scan("com.niit.shopingcart");
context.refresh();

ProductDAO productDAO=(ProductDAO)context.getBean("productDAO");

Product product=(Product)context.getBean("product");

product.setId("SG200");
product.setName("HTC");
product.setDescription("SG278");
product.setPrice("5000");

productDAO.saveOrUpdate(product);

if(productDAO.get("SG200")==null)
{
	System.out.println("product does not exist....");
}
else
{
	  System.out.println("product exists.....");
}
 
	}

}
