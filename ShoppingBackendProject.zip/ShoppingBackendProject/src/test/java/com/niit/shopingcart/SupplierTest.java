package com.niit.shopingcart;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shopingcart.dao.SupplierDAO;
import com.niit.shopingcart.model.Supplier;

public class SupplierTest {

	public static void main(String[] args) {
	
		   
  AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
  context.scan("com.niit.shopingcart");
  context.refresh();
  
 SupplierDAO SupplierDAO=(SupplierDAO)context.getBean("supplierDAO");
  
  Supplier supplier=(Supplier)context.getBean("supplier");
  supplier.setId("SIDDU120");
  supplier.setName("Kumar120");
  supplier.setAddress("Antp120");
  
 SupplierDAO.saveOrUpdate(supplier);
	
  
  if(SupplierDAO.get("SIDDU120")==null)
  {
	  System.out.println("supplier does not exist");
  }
  else
  {
	  System.out.println("supplier exist .. the details are ..");
	  System.out.println();
  }
	
  }
}